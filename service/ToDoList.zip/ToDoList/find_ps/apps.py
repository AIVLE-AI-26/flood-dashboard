from django.apps import AppConfig


class FindPsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "find_ps"
